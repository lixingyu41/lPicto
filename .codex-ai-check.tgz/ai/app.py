import base64
import io
import json
import os
import subprocess
import tempfile
import threading
from pathlib import Path

import httpx
import numpy as np
import onnxruntime as ort
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from PIL import Image, ImageOps
from transformers import ChineseCLIPProcessor

from taxonomy import LABELS, TAXONOMY_VERSION
from media_sampling import sample_ratios

MODEL_DIR = Path("/models/chinese-clip")
MEDIA_ROOT = Path("/Media").resolve()
CACHE_ROOT = Path("/cache").resolve()
TAG_MODEL = "Chinese-CLIP-ViT-B-16"
TAG_MODEL_VERSION = "Xenova-f26904860903e70e050b8f48255e5f48401816e9"
DESCRIPTION_MODEL = "Qwen3-VL-2B-Instruct-Q4_K_M"
DESCRIPTION_MODEL_VERSION = "Qwen-52d6c8ffea26cc873ac5ad116f8631268d7eb503"
LOCK = threading.Lock()

class AnalyzeRequest(BaseModel):
    assetId: int
    relPath: str
    mediaType: str
    cacheKey: str
    duration: float | None = None

app = FastAPI(title="lPicto local AI", docs_url=None, redoc_url=None)
processor = ChineseCLIPProcessor.from_pretrained(MODEL_DIR, local_files_only=True)
session = ort.InferenceSession(str(MODEL_DIR / "onnx/model.onnx"), providers=["CPUExecutionProvider"])
input_names = {item.name for item in session.get_inputs()}
output_names = [item.name for item in session.get_outputs()]

def _onnx_inputs(batch):
    return {key: np.asarray(value) for key, value in batch.items() if key in input_names}

def _output(outputs, wanted):
    for name, value in zip(output_names, outputs):
        if wanted in name.lower():
            return value
    raise RuntimeError(f"ONNX output {wanted!r} missing: {output_names}")

def _text_embeddings():
    dummy = Image.new("RGB", (224, 224), "gray")
    vectors = []
    for start in range(0, len(LABELS), 100):
        prompts = [f"一张关于{label}的照片" for label in LABELS[start:start + 100]]
        batch = processor(text=prompts, images=dummy, return_tensors="np", padding=True)
        outputs = session.run(None, _onnx_inputs(batch))
        vectors.append(_output(outputs, "text_embeds"))
    value = np.concatenate(vectors, axis=0).astype(np.float32)
    return value / np.maximum(np.linalg.norm(value, axis=1, keepdims=True), 1e-12)

TEXT_EMBEDDINGS = _text_embeddings()

def _safe_media_path(rel_path):
    target = (MEDIA_ROOT / rel_path.replace("\\", "/")).resolve()
    if MEDIA_ROOT not in target.parents:
        raise ValueError("media path escapes root")
    return target

def _video_frames(path, duration):
    ratios = sample_ratios(duration)
    frames = []
    with tempfile.TemporaryDirectory(prefix="lpicto-ai-") as temp:
        for index, ratio in enumerate(ratios):
            out = Path(temp) / f"{index}.jpg"
            timestamp = max(0.0, float(duration or 0) * ratio)
            command = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-ss", f"{timestamp:.3f}", "-i", str(path), "-frames:v", "1", "-vf", "scale='min(1280,iw)':-2", "-q:v", "3", "-y", str(out)]
            subprocess.run(command, check=True, timeout=120)
            with Image.open(out) as image:
                frames.append((ratio, image.convert("RGB").copy()))
    return frames

def _load_frames(request):
    media_path = _safe_media_path(request.relPath)
    if not media_path.is_file():
        raise FileNotFoundError(media_path)
    if request.mediaType == "video":
        return _video_frames(media_path, request.duration)
    preview = CACHE_ROOT / "previews" / f"{request.cacheKey}.webp"
    source = preview if preview.is_file() else media_path
    with Image.open(source) as image:
        return [(0.0, ImageOps.exif_transpose(image).convert("RGB"))]

def _image_embedding(image):
    batch = processor(text=["照片"], images=image, return_tensors="np", padding=True)
    outputs = session.run(None, _onnx_inputs(batch))
    value = _output(outputs, "image_embeds").astype(np.float32)
    return value / np.maximum(np.linalg.norm(value, axis=1, keepdims=True), 1e-12)

def _tags(frames):
    image_vector = np.mean(np.concatenate([_image_embedding(image) for _, image in frames], axis=0), axis=0)
    image_vector /= max(float(np.linalg.norm(image_vector)), 1e-12)
    scores = TEXT_EMBEDDINGS @ image_vector
    order = np.argsort(scores)[::-1]
    top = float(scores[order[0]])
    result = []
    for index in order:
        score = float(scores[index])
        if score < 0.24 or top - score > 0.06:
            continue
        result.append({"tag": LABELS[int(index)], "confidence": round(score, 6)})
        if len(result) == 8:
            break
    return result

def _data_url(image):
    copy = image.copy(); copy.thumbnail((1280, 1280))
    output = io.BytesIO(); copy.save(output, "JPEG", quality=85, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(output.getvalue()).decode("ascii")

def _description(frames, media_type):
    prompt = "请用20到80个简体中文字符客观描述这张图片中可见的主体、场景和动作。禁止推测人物身份、精确地点或画面外事件，只输出一条描述。"
    if media_type == "video":
        prompt = "以下图片按视频时间顺序抽取。请用20到80个简体中文字符客观概括可见主体、场景和动作变化。禁止推测人物身份、精确地点或未显示事件，只输出一条描述。"
    content = [{"type": "text", "text": prompt}] + [{"type": "image_url", "image_url": {"url": _data_url(image)}} for _, image in frames]
    payload = {"model": DESCRIPTION_MODEL, "messages": [{"role": "user", "content": content}], "temperature": 0.1, "max_tokens": 160, "stream": False}
    response = httpx.post("http://127.0.0.1:8091/v1/chat/completions", json=payload, timeout=600)
    response.raise_for_status()
    text = response.json()["choices"][0]["message"]["content"].strip().strip('“”"')
    return "".join(text.splitlines()).strip()

@app.get("/health")
def health():
    return {"status": "ok", "taxonomyCount": len(LABELS), "taxonomyVersion": TAXONOMY_VERSION}

@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    if request.mediaType not in ("image", "video"):
        raise HTTPException(400, "unsupported media type")
    try:
        with LOCK:
            frames = _load_frames(request)
            tags = _tags(frames)
            description = _description(frames, request.mediaType)
        return {"description": description, "tags": tags, "tagModel": TAG_MODEL, "tagModelVersion": TAG_MODEL_VERSION, "descriptionModel": DESCRIPTION_MODEL, "descriptionModelVersion": DESCRIPTION_MODEL_VERSION, "taxonomyVersion": TAXONOMY_VERSION, "sampledFrames": [{"ratio": ratio} for ratio, _ in frames]}
    except Exception as exc:
        raise HTTPException(500, str(exc)) from exc
