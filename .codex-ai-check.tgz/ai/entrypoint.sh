#!/bin/sh
set -eu
MODEL=/models/Qwen3VL-2B-Instruct-Q4_K_M.gguf
MMPROJ=/models/mmproj-Qwen3VL-2B-Instruct-Q8_0.gguf
CLIP=/models/chinese-clip/onnx/model.onnx
for file in "$MODEL" "$MMPROJ" "$CLIP"; do
  test -s "$file" || { echo "required model missing: $file" >&2; exit 42; }
done
llama-server -m "$MODEL" --mmproj "$MMPROJ" --host 127.0.0.1 --port 8091 -c 8192 -t 6 -ngl 0 --parallel 1 > /tmp/llama-server.log 2>&1 &
LLAMA_PID=$!
trap 'kill "$LLAMA_PID" 2>/dev/null || true' EXIT INT TERM
i=0
until curl -fsS http://127.0.0.1:8091/health >/dev/null; do
  i=$((i+1)); test "$i" -lt 180 || { cat /tmp/llama-server.log >&2; exit 43; }
  kill -0 "$LLAMA_PID" 2>/dev/null || { cat /tmp/llama-server.log >&2; exit 44; }
  sleep 1
done
exec uvicorn app:app --host 0.0.0.0 --port 8090 --workers 1
