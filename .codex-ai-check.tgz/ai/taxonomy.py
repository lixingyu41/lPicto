"""Deterministic Chinese-CLIP taxonomy. The public label set is fixed at 800 entries."""

TAXONOMY_VERSION = "lpicto-zh-800-v1"

_BASE = """
人物 男人 女人 男孩 女孩 婴儿 老人 家庭 朋友 情侣 人群 肖像 自拍 合影 婚礼 毕业 生日 聚会 演出 舞蹈 音乐会 运动员 游客 工人 厨师 医生 警察
猫 狗 鸟 鱼 马 牛 羊 猪 兔子 仓鼠 鹿 猴子 熊 狐狸 狼 狮子 老虎 大象 长颈鹿 熊猫 企鹅 海豚 鲸鱼 乌龟 蛇 蜥蜴 蝴蝶 蜜蜂 昆虫 宠物 野生动物
天空 云朵 日出 日落 月亮 星空 彩虹 雨 雪 雾 闪电 山脉 丘陵 森林 树木 草地 花朵 植物 竹林 沙漠 海滩 海洋 湖泊 河流 瀑布 岩石 洞穴 田野 农场 公园 花园
城市 街道 建筑 高楼 房屋 村庄 商店 商场 市场 餐厅 咖啡馆 酒店 学校 教室 图书馆 医院 博物馆 寺庙 教堂 城堡 桥梁 隧道 车站 机场 港口 工厂 工地
汽车 卡车 公交车 出租车 摩托车 自行车 火车 地铁 飞机 直升机 轮船 帆船 快艇 道路 高速公路 铁路 停车场 交通灯 车内 驾驶 航行 飞行
食物 米饭 面条 面包 蛋糕 甜点 冰淇淋 巧克力 水果 苹果 香蕉 橙子 草莓 葡萄 西瓜 蔬菜 沙拉 肉类 牛肉 猪肉 鸡肉 海鲜 鱼类 火锅 烧烤 早餐 午餐 晚餐 饮料 咖啡 茶 酒
手机 电脑 笔记本电脑 平板电脑 相机 镜头 电视 音箱 耳机 手表 键盘 鼠标 屏幕 电路板 机器人 无人机 游戏机 电器 工具 机器 设备 灯具 家具 桌子 椅子 沙发 床 柜子
客厅 卧室 厨房 浴室 餐厅 阳台 走廊 楼梯 门窗 室内 室外 办公室 会议室 车间 仓库 体育馆 游泳池 操场 舞台 展厅 商店内部
足球 篮球 排球 网球 羽毛球 乒乓球 棒球 高尔夫 游泳 跑步 骑行 滑雪 滑板 冲浪 瑜伽 健身 登山 徒步 露营 钓鱼 划船 赛车 游戏 阅读 写字 绘画 摄影 烹饪 工作 学习
衣服 连衣裙 外套 裤子 鞋子 帽子 眼镜 包 首饰 制服 西装 婚纱 玩具 书籍 文件 纸张 海报 标志 文字 包装 礼物 鲜花 雕塑 艺术品 乐器 吉他 钢琴 鼓
白天 夜晚 春天 夏天 秋天 冬天 晴天 阴天 雨天 雪天 风景 夜景 航拍 特写 全景 黑白照片 老照片 截图 动画 插画 绘画 表格 文档 证件 商品 静物
红色 蓝色 绿色 黄色 橙色 紫色 粉色 黑色 白色 灰色 棕色 金色 银色 明亮 昏暗 温暖 寒冷 干净 杂乱 空旷 拥挤 可爱 美丽 现代 传统 古老 新鲜 破损
""".split()

_COMPOUND_NOUNS = "猫 狗 鸟 汽车 自行车 火车 飞机 轮船 房屋 建筑 街道 山脉 森林 海滩 海洋 湖泊 花朵 食物 蛋糕 水果 手机 电脑 相机 家具 衣服 玩具 书籍 艺术品 天空 云朵".split()
_MODIFIERS = "红色 蓝色 绿色 黄色 黑色 白色 灰色 棕色 金色 银色 可爱 小型 大型 老旧 现代 木制 金属 玻璃 室内 室外 夜间 雨中 雪中".split()

def _build():
    items = []
    for value in _BASE:
        if value not in items:
            items.append(value)
    for modifier in _MODIFIERS:
        for noun in _COMPOUND_NOUNS:
            value = modifier + noun
            if value not in items:
                items.append(value)
            if len(items) == 800:
                return tuple(items)
    raise RuntimeError(f"taxonomy only contains {len(items)} labels")

LABELS = _build()
assert len(LABELS) == 800 and len(set(LABELS)) == 800
